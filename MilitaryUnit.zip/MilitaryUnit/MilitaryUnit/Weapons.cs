﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MilitaryUnit
{
    class Weapons : Equipment
    {
        public void m16()
        {
            Console.WriteLine("M16A4 Rifle");
        }

        public void m1014()
        {
            Console.WriteLine("M1014 Shotgun");
        }

        public void m240()
        {
            Console.WriteLine("M240 Machine Gun");
        }
    }
}
