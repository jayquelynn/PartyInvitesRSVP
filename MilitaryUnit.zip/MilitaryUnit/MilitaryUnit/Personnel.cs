﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MilitaryUnit
{
    class Personnel
    {
        public void Pvt()
        {
            Console.WriteLine("Private");
        }

        public void Lcpl()
        {
            Console.WriteLine("Lance Corporal");
        }

        public void Cpl()
        {
            Console.WriteLine("Corporal");
        }

        public void Sgt()
        {
            Console.WriteLine("Sergeant");
        }

        public void SSgt()
        {
            Console.WriteLine("Staff Sergeant");
        }

        public void GySgt()
        {
            Console.WriteLine("Gunnery Sergeant");
        }

        public void MSgt()
        {
            Console.WriteLine("Master Sergeant");
        }

        public void ISgt()
        {
            Console.WriteLine("First Sergeant");
        }

        public void MGysgt()
        {
            Console.WriteLine("Master Gunnery Sergeant");
        }

        public void SgtMaj()
        {
            Console.WriteLine("Sergeant Major");
        }
    }
}
