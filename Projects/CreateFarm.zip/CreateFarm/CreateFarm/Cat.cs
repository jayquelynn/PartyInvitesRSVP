﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateFarm
{
    class Cat
    {
        public void Speak()
        {
            Console.WriteLine("Hi, I am Carmen and I am a cat");
        }

        public void Sound()
        {
            Console.WriteLine("I make the sound, 'Meow!'");
        }

        public void Eats()
        {
            Console.WriteLine("I like to eat fish, rice and spinach!");
        }

        public void Activity()
        {
            Console.WriteLine("I don't do much so, I like lounging around and sleeping");
        }
    }
}
