﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateFarm
{
    class Cow
    {
        public void Speak()
        {
            Console.WriteLine("Hi, I am Carl and I am a cow.");
        }

        public void Sound()
        {
            Console.WriteLine("I make the sound, Mooo!");
        }

        public void Eats()
        {
            Console.WriteLine("I like to eat grains and corn.");
        }

        public void Activity()
        {
            Console.WriteLine("I really like to relax and not do much.");
        }
    }
}
