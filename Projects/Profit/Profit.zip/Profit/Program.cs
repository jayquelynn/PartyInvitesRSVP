﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Profit
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                Console.WriteLine("Amount of Total Sales");
                string name = Console.ReadLine();
                double AmountOfTotalSales = Convert.ToDouble(name);
                double Profit = AmountOfTotalSales * 0.23;
                Console.WriteLine($"The profit is {Profit = 0.00}");

            }
        }
    }
}
