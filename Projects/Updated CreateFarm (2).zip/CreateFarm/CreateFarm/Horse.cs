﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateFarm
{
    class Horse
    {
        public void Speak()
        {
            Console.WriteLine("Hi, I am Harry and I am a Horse");
        }

        public void Sound()
        {
            Console.WriteLine("I make the sound, 'Neigh!'");
        }

        public void Eats()
        {
            Console.WriteLine("I like to eat all types of food too! My favorite food is hay and apples");
        }

        public void Activity()
        {
            Console.WriteLine("I like to race other horsess to see who is faster!");
            Console.ReadLine();
        }
    }
}
