﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateFarm
{
    class Pig
    {
        public void Speak()
        {
            Console.WriteLine("Hi, I am Paul!");
        }

        public void Sound()
        {
            Console.WriteLine("I am a pig and I make the seound, Oink");
        }

        public void Eats()
        {
            Console.WriteLine("I like to eat corn and fruits");
        }

        public void Activity()
        {
            Console.WriteLine("I really just like to eat!!");
            Console.ReadLine();
        }
    }
}
