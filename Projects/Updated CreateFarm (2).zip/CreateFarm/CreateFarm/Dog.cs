﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateFarm
{
    class Dog
    {
        public void Speak()
        {
            Console.WriteLine("Hello! I am Dave the dog. Nice to meet you!");
        }

        public void Sound()
        {
            Console.WriteLine("I am a dog and I make the sound, 'Woof!'");
        }

        public void Eats()
        {
            Console.WriteLine("I like to eat all types of food! But my owners usually feed me dog food");
        }

        public void Activity()
        {
            Console.WriteLine("I like to chase Sherry and the sheep!");
            Console.ReadLine();
        }
    }
}
