﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateFarm
{
    class Sheep
    {
        public void Speak()
        {
            Console.WriteLine("Hi, I am Sherry!");
        }

        public void Sound()
        {
            Console.WriteLine("I am a sheep and I make the sound, 'Baa!'");
        }

        public void Eats()
        {
            Console.WriteLine("I love eating grass!");
        }

        public void Activity()
        {
            Console.WriteLine("I like to interact with the children who come to see me!");
            Console.ReadLine();
        }
    }
}
